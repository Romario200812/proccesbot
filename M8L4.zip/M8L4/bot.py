import telebot
import psutil

token='8007643410:AAEUM3gCFZ5cFA5Y0XaQq1omS6am5_HfhE4'

bot=telebot.TeleBot(token)

@bot.message_handler(commands=['start'])
def send_proccesses(message):
  bot.send_message(message.chat.id,"Привет ✌️ ")

@bot.message_handler(commands=['cpu'])
def send_cpu_info(message):
    cpu_usage = psutil.cpu_percent(interval=0)
    cpu_cores_usage = psutil.cpu_percent(percpu=True)
    cpu_freq = psutil.cpu_freq()

    text =  f'''"характерискики процессора" \\
    "1. *общая загрузка:* {cpu_usage}
    "2. *загрузка первых 3 ядер:* {cpu_cores_usage[:3]}
    "3. *частота:* {cpu_freq.current} МГц (макс: {cpu_freq.max:,0f} МГц 
    '''


    bot.reply_to(message, text, parse_mode="markdown")

@bot.message_handler(commands=['disks'])
def send_disk_info(message):
    disk = psutil.disk_usage('/')

    total = disk.total / (1024 ** 3)
    used = disk.used / (1024 ** 3)
    free = disk.free / (1024 ** 3)

    text =   f""" *характерискики процессора:* 
    "1. *всего памяти:* {total: ,1f}
    "2. *занято место:* {used: ,1f[:3]}
    
    """
    bot.reply_to(message, text, parse_mode="markdown")


bot.infinity_poling()